 import React, { useContext } from "react";
import { ShopContext } from "../Context/ShopContext";
import Item from "../components/Item";
import dropdown from "../assets/dropdown_icon.png";

const ShopCatogory = (props) => {
  const { all_products } = useContext(ShopContext);

  console.log("All products in ShopCatogory:", all_products); // Debug: Check if products are being fetched

  return (
    <>
      <div className="catogory">
        <img src={props.banner} alt="" />

        <div className="flex justify-between items-center px-4 text-xs md:px-24 py-8 sm:text-sm">
          <p>Showing 1-12 out of {all_products.length} products</p>
          <button className="flex gap-2 border-[1.5px] rounded-full justify-between items-center px-3 sm:px-5 py-2">
            Sort By <img className="w-2" src={dropdown} alt="" />
          </button>
        </div>

        <div className="flex justify-center flex-wrap gap-3  md:gap-6 px-6 md:px-24 sm:py-8">
          {all_products.length > 0 ? (
            all_products.map((item, i) => {
              if (props.category === item.category) {
                return (
                  <Item
                    key={i}
                    id={item.id}
                    name={item.name}
                    old_price={item.old_price}
                    new_price={item.new_price}
                    image={item.image}
                  />
                );
              } else {
                return null;
              }
            })
          ) : (
            <p>No products found</p>
          )}
        </div>
        <div className="text-center py-12">
          <button className="px-5 py-2 rounded-full border-[1.5px] border-black hover:border-white hover:bg-red-500 hover:text-white">
            Explore More
          </button>
        </div>
      </div>
    </>
  );
};

export default ShopCatogory;

