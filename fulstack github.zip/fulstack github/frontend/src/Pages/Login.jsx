import React, { useState } from "react";

const Login = () => {
  const [state, setstate] = useState("Login");
  const [form, setform] = useState({
    username: "",
    password: "",
    email: "",
  });
  const LOGIN = async () => {
    console.log("logined", form);

    try {
      const response = await fetch("http://localhost:4000/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(form),
      });
      const data = await response.json();
      if (data.success) {
        localStorage.setItem("auth-token", data.token);
        window.location.replace("/");
      } else {
        console.error("Signup failed:", data.errors);
      }
    } catch (error) {
      console.error("An error occurred:", error);
    }
  };
  const Signup = async () => {
    console.log("signup", form);
    try {
      const response = await fetch("http://localhost:4000/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(form),
      });
      const data = await response.json();
      if (data.success) {
        localStorage.setItem("auth-token", data.token);
        window.location.replace("/");
      } else {
        console.error("Signup failed:", data.errors);
      }
    } catch (error) {
      console.error("An error occurred:", error);
    }
  };

  const handle = (e) => {
    setform({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <>
      <section className="  bg-gradient-to-b from-pink-300 to-pink-50 ">
        <div className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
          <div className="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 ">
            <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
              {state === "Login" ? (
                <h1 className="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl ">
                  Sign In
                </h1>
              ) : (
                <h1 className="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl ">
                  Sign Up
                </h1>
              )}
              <div className="space-y-4 md:space-y-6  ">  {/* //form */}
               
                <div>
                  {state === "signup" ? (
                    <input
                      onChange={handle}
                      type="text"
                      name="username"
                      value={form.username}
                      id="text"
                      className="bg-gray-50 border border-gray-300 text-gray-900 rounded-full focus:ring-primary-600 focus:border-primary-600 block w-full py-2.5 px-5    "
                      placeholder="Your Name"
                      required=""
                    />
                  ) : (
                    <></>
                  )}
                </div>
                <div>
                  <input
                    onChange={handle}
                    type="email"
                    value={form.email}
                    name="email"
                    id="email"
                    className="bg-gray-50 border rounded-full border-gray-300 text-gray-900  focus:ring-primary-600 focus:border-primary-600 block w-full py-2.5 px-5     "
                    placeholder="E-mail Address"
                    required=""
                  />
                </div>
                <div>
                  <input
                    onChange={handle}
                    type="password"
                    name="password"
                    value={form.password}
                    id="password"
                    placeholder="Password"
                    className="bg-gray-50 border border-gray-300 text-gray-900 rounded-full focus:ring-primary-600 focus:border-primary-600 block w-full py-2.5 px-5   "
                    required=""
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        aria-describedby="remember"
                        type="checkbox"
                        className="w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-primary-300   "
                        required=""
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label className="text-gray-500 ">Remember me</label>
                    </div>
                  </div>
                  <a
                    href="#"
                    className="text-sm font-medium text-primary-600 hover:underline  "
                  >
                    Forgot password?
                  </a>
                </div>
                <button
                  type="button" // Ensure this is not a submit button
                  onClick={() => {
                    state === "Login" ? LOGIN() : Signup();
                  }}
                  className=" w-full  text-gray-500 bg-primary-600    rounded-full border-[1.5px] text-sm px-5 py-2.5 text-center  "
                >
                  {state === "Login" ? <p>Sign In</p> : <p>Sign Up</p>}
                </button>

                {state === "Login" ? (
                  <p className="text-sm font-light text-gray-500 ">
                    Don’t have an account yet?{" "}
                    <a
                      onClick={() => setstate("signup")}
                      href="#"
                      className="font-medium text-primary-600 hover:underline "
                    >
                      Sign up
                    </a>
                  </p>
                ) : (
                  <></>
                )}
                {state === "signup" ? (
                  <p className="text-sm font-light text-gray-500 ">
                    Already have an account ?{" "}
                    <a
                      onClick={() => setstate("Login")}
                      href="#"
                      className="font-medium text-primary-600 hover:underline "
                    >
                      Login Here
                    </a>
                  </p>
                ) : (
                  <></>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Login;
