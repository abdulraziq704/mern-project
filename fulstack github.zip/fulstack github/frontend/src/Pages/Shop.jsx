import React from "react";
import hero from "../assets/hero_image.png";
import arrow from "../assets/arrow.png";
import Popular from "../components/Popular";
import banner from "../assets/exclusive_image.png";
import Collection from "../components/Collection";
import Newsletter from "../components/Newsletter";

const Shop = () => {
  return (
    <>
      <div className="her font-poppins py-6 px-4  md:px-24 md:py-12 md:flex justify-between items-center bg-gradient-to-b from-pink-300 to-pink-50">
        <div className="md:w-1/2   pt-5 sm:pt-0  ">
          <h3 className="md:text-lg font-bold uppercase">New Arrivals Only</h3>
          <h2 className="  text-4xl lg:text-6xl font-semibold uppercase lg:leading-[64px]">
            New <br /> Collections <br />
            For Everyone
          </h2>
          <button className="bg-red-500 rounded-full px-8 py-2 text-center text-white mt-5 flex gap-3 justify-center items-center">
            Latest Collection <img className="w-4" src={arrow} alt="" />
          </button>
        </div>
        <div className=" md:w-1/2 pt-6 sm:pt-0 flex justify-center items-center text-center">
          <img className="w-2/3" src={hero} alt="" />
        </div>
      </div>
      <Popular />
      <div className="md:px-12 px-6  py-12 ">
        <div className="banner md:flex justify-between items-center bg-gradient-to-b pt-4 px-6  from-pink-200  to-white">
          <div className="md:w-1/2 md:px-7">
            <h2 className=" text-3xl leading[40px] sm:text-5xl font-bold sm:leading-[52px]">
              Exlusive <br /> Offers For You
            </h2>
            <h3 className="sm:text-lg font-normal uppercase py-2">
              Only on Best seller Products
            </h3>

            <button className="bg-red-500 rounded-full px-8 py-2 text-white mt-5 ">
              Check Now
            </button>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <img className="w-52" src={banner} alt="" />
          </div>
        </div>
      </div>
      <Collection/>
      <Newsletter/>
    </>
  );
};

export default Shop;
