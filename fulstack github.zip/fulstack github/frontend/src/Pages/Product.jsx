import React, { useContext } from 'react'
import { useParams } from 'react-router-dom';
import { ShopContext } from '../Context/ShopContext';
import Bread from '../components/Bread';
import DisplayProduct from '../components/DisplayProduct';

const Product = () => {
  const {all_products}= useContext(ShopContext);
  const {productID} = useParams();
const product = all_products.find((e)=>e.id === Number(productID))
console.log(product);
  return (
    <div>
        <Bread product={product}/>
        <DisplayProduct product={product}/>
    </div>
  )
}

export default Product