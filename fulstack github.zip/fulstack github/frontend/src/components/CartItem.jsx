import React, { useContext } from "react";
import { ShopContext } from "../Context/ShopContext";
import cross from "../assets/cart_cross_icon.png";

const CartItem = () => {
  const { all_products, GetAmount, cartItem, addtocart, removetocart } =
    useContext(ShopContext);
  console.log("cartItem:", cartItem);

  return (
    <>
      <div className="md:px-24 px-6 py-6 font-poppins">
        <div className=" flex flex-wrap gap-2 justify-center md:grid md:grid-cols-6 font-semibold text-sm pt-9 pb-4 border-b border-black">
          <p className="col-span-2 ">Products</p>

          <p>Price</p>
          <p>Quantity</p>
          <p>Total</p>
          <p>Remove</p>
        </div>
        {all_products.map((e) => {
          console.log("Product ID:", e.id);
          console.log("Quantity in cart:", cartItem[e.id]);

          if (cartItem[e.id] > 0) {
            console.log(e.id);
            console.log("Displaying product with ID:", e.id);
            return (
              <div className="" key={e.id}>
                <div
                  
                  className="grid grid-cols-6  justify-center items-center  py-4  text-sm"
                >
                  <div className="col-span-2 flex gap-2  justify-center">
                    <img
                      className="w-12 sm:block hidden"
                      src={e.image}
                      alt=""
                    />
                    <p className="pr-6 text-xs sm:text-base">{e.name}</p>
                  </div>
                  <p>${e.new_price}</p>
                  <button className="  inline-flex">{cartItem[e.id]}</button>
                  <p>${e.new_price * cartItem[e.id]}</p>
                  <button>
                    <img
                      className="mx-5 w-3"
                      onClick={() => {
                        removetocart(e.id);
                      }}
                      src={cross}
                      alt=""
                    />
                  </button>
                </div>
                <hr />
              </div>
            );
          }
        })}

        <div className="lg:grid lg:grid-cols-2 gap-7 py-5 flex flex-wrap-reverse  md:py-12">
          <div className="left md:pr-12 w-full">
            <h3 className="font-bold py-3">Cart Totals</h3>
            <div className="flex justify-between py-3 px-2 border-b text-sm border-black">
              <p>SubTotal</p>
              <p>${GetAmount()}</p>
            </div>
            <div className="flex justify-between py-3  px-2  border-b text-sm border-black">
              <p>Shipping Fee</p>
              <p>FREE</p>
            </div>
            <div className="flex justify-between py-3 px-2  border-b text-sm border-black font-bold">
              <p>Total</p>
              <p>${GetAmount()}</p>
            </div>
            <button className="hover:bg-red-500  hover:text-white py-2 px-4 sm:px-5 sm:py-3 mt-4 bg-black text-white">
              Proceed To CheckOut
            </button>
          </div>
          <div className="right md:pl-5 w-full md:pr-12 text-sm">
            <p>If You Have a Promo Code, Enter it Here</p>
            <div className="flex justify-between  mt-3   bg-gray-200 ">
              <input
                className="w-full outline-none bg-transparent px-3"
                type="text"
                placeholder="Promo Code"
              />
              <button className="px-6 py-3 bg-black text-white">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CartItem;
