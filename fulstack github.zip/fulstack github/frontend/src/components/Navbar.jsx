import React, { useContext, useState } from "react";
import { Link } from "react-router-dom";
import logo from "../assets/logo.png";
import cart from "../assets/cart_icon.png";
import { ShopContext } from "../Context/ShopContext";
import FaBars from "../assets/icons8.svg";
import FaTimes from "../assets/icons8-2.svg";
const Navbar = () => {
  const { GetItem } = useContext(ShopContext);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      <header>
        <nav className="flex justify-between items-center border font-poppins bg-white py-3 px-6 md:px-24">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2 font-bold">
              <img className="w-10" src={logo} alt="Logo" />
              SHOPPER
            </Link>
          </div>
          <div className="hidden md:flex gap-6 text-sm">
            <Link to="/">Shop</Link>
            <Link to="/men">Men</Link>
            <Link to="/women">Women</Link>
            <Link to="/kid">Kids</Link>
          </div>
          <div className="flex gap-x-5 items-center">
           
              {
                localStorage.getItem('auth-token')?  <button
                onClick={()=>{localStorage.removeItem('auth-token');window.location.replace("/")}}
                   className="hidden md:inline-block rounded-full px-6 py-2 border-[1.5px] border-black leading-4"
                > Logout
            </button>: <Link
                   to="/login"
                  className="hidden md:inline-block rounded-full px-6 py-2 border-[1.5px] border-black leading-4"
                > Login
            </Link>
              }
             
            <div className="relative">
              <Link to="/cart" className="">
                <img className="w-6" src={cart} alt="Cart" />
              </Link>
              <p className="absolute -right-4 -top-2 text-[11px] bg-red-600 p-1 rounded-full text-white leading-none">
                {GetItem()}
              </p>
            </div>
            <button className="md:hidden text-xl" onClick={toggleMobileMenu}>
              {isMobileMenuOpen ? (
                <>
                  <img src={FaTimes} alt="" />
                </>
              ) : (
                <>
                  <img src={FaBars} alt="" />
                </>
              )}
            </button>
          </div>
        </nav>
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="flex flex-col items-center gap-6 text-sm py-4">
              <Link to="/" onClick={toggleMobileMenu}>
                Shop
              </Link>
              <Link to="/men" onClick={toggleMobileMenu}>
                Men
              </Link>
              <Link to="/women" onClick={toggleMobileMenu}>
                Women
              </Link>
              <Link to="/kid" onClick={toggleMobileMenu}>
                Kids
              </Link>
              <Link
                to="/login"
                className="rounded-full px-6 py-2 border-[1.5px] border-black leading-4"
                onClick={toggleMobileMenu}
              >
                Login
              </Link>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

export default Navbar;
