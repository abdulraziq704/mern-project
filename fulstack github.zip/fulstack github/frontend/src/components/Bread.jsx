import React from "react";
import arrow from "../assets/bread.png";

const Bread = (props) => {
  const { product } = props;
  return (
    <>
      <div className="flex flex-wrap gap-x-4 gap-y-2 text-xs sm:justify-center items-center pt-6 pb-6 sm:pb-12 sm:px-24 px-4">
        Home <img src={arrow} className="w-1" alt="" /> Shop 
        <img src={arrow} alt="" className="w-1" /> {product.category} <img src={arrow} alt="" className="w-1"/> {product.name}
      </div>
    </>
  );
};

export default Bread;
