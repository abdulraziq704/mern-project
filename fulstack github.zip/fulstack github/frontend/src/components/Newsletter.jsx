import React from "react";

const Newsletter = () => {
  return (
    <>
    <div className="  md:px-12 px-4  sm:py-8 text-center">
    <div className="md:flex justify-center items-center flex-col bg-gradient-to-b py-8 sm:py-16 from-pink-200 px-2 sm:px-4 to-white ">
        <h2 className="sm:text-5xl text-3xl leading-[40px] font-semibold sm:leading-[52px]">Get Exclusive Offers On Your Emial</h2>
        <p className="text-lg font-normal   pt-7 pb-6">Subscribe to our newsletter and stayed update</p>
        <div className=" border-2 md:w-1/2 border-black flex justify-between items-center rounded-full pl-5">
          <input className=" outline-none border-none   w-full  bg-transparent" type="email" placeholder=" Your Email Id" />{" "}
          <button className="bg-black text-white px-5 sm:px-8 py-2 sm:py-3 rounded-full text-sm">Subscribe</button>
        </div>
      </div>
    </div>
      
    </>
  );
};

export default Newsletter;
