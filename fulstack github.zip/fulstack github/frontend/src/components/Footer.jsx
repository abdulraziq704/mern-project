import React from "react";
import fb from "../assets/instagram_icon.png";
import biglogio from "../assets/logo_big.png";
import pin from "../assets/pin.png";
import whats from "../assets/whats.png";

const Footer = () => {
  return (
    <>
      <div className="font-poppins text-center pt-12 pb-2">
        <div className=" flex justify-center items-center gap-3 font-bold text-3xl">
          <img className="w-16" src={biglogio} alt="" />
          SHOPPER
        </div>

        <ul className="list-none md:flex gap-4 justify-center items-center py-6">
          <li>Company</li>
          <li>Products</li>
          <li>Offices</li>
          <li>About</li>
          <li>Contact</li>
        </ul>
        <div className="sociall flex justify-center items-center py-2  gap-5">
          <img className="w-6" src={fb} alt="" />
          <img className="w-6" src={pin} alt="" />
          <img className="w-6" src={whats} alt="" />
        </div>
        <p className="mt-8 pt-3 border-t border-black leading-4 mx-auto w-[90%] text-sm">Copyright © 2023 - All Right Reserved</p>
      </div>
    </>
  );
};

export default Footer;
