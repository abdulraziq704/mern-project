import React, { useEffect, useState } from "react";
import Item from "./Item";

const Collection = () => {
  const [newcollection, setnew_collection] = useState([]);

  useEffect(() => {
    fetch("http://localhost:4000/new-collection")
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        console.log('Fetched data:', data);
        setnew_collection(data);
      })
      .catch((error) => {
        console.error('There has been a problem with your fetch operation:', error);
      });
  }, []);
  

  return (
    <>
      <div className="font-poppins py-20">
        <h1 className="sm:text-4xl text-2xl font-bold text-center uppercase py-3">
          New Collection
        </h1>
        <hr className="w-32 border-t-4 border-gray-600 mx-auto rounded-full" />
        <div className=" flex justify-center flex-wrap gap-8 sm:gap-y-16 px-6 md:px-24 py-8">
          {newcollection.map((item, i) => {
            return (
              <Item
                key={i}
                id={item.id}
                name={item.name}
                old_price={item.old_price}
                new_price={item.new_price}
                image={item.image}
              />
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Collection;
