import React from "react";
import { Link } from "react-router-dom";

const Item = (props) => {
  return (
    <div>
      <div className=" font-poppins w-60 flex flex-col justify-center  ">
       <Link to={`/product/${props.id} ` }>
        <img 
          className="hover:scale-105 transition-transform	"
          onClick={window.scrollTo(0,0)}
          src={props.image}
          alt=""
        />
        </Link>
        <p className="text-xl font-bold pt-6 leading-6">{props.name}</p>
        <div className=" flex gap-3 text-lg ">
          <p className="font-bold">${props.new_price}</p>

          <p className="text-gray-500 line-through">${props.old_price}</p>
        </div>
      </div>
    </div>
  );
};

export default Item;
