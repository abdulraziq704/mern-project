import React, { useEffect, useState } from "react";
import Item from "./Item";

const Popular = () => {
  const [populars, setpopular] = useState([]);
   
  useEffect(() => {
    fetch("http://localhost:4000/popular")
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        console.log('Fetched popular data:', data); // Debug: Log fetched data
        setpopular(data);
      })
      .catch((error) => {
        console.error('There has been a problem with your fetch operation:', error); // Debug: Log errors
      });
  }, []);
  
  return (
    <>
      <div className="font-poppins py-6 md:py-20">
        <h1 className="sm:text-4xl text-2xl font-bold text-center py-3 uppercase">
          Pupolar Arrival
        </h1>
        <hr className="w-32 border-t-4 border-gray-600 mx-auto rounded-full" />
        <div className="flex flex-wrap justify-center  gap-7 px-6 md:px-24 py-8">
          {populars.map((item, i) => {
            return (
              <Item
                key={i}
                id={item.id}
                name={item.name}
                old_price={item.old_price}
                new_price={item.new_price}
                image={item.image}
              />
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Popular;
