import React, { createContext, useState, useEffect } from "react";
// import all_products from "../assets/all_product.js";

export const ShopContext = createContext(null);

const getCart = () => {
  let cart = {};
  for (let index = 0; index < 300 + 1; index++) {
    cart[index] = 0;
  }
  return cart;
};

const ShopContextProvider = (props) => {
  const [all_products, setall_products] = useState([]);
  const [cartItem, setcartItem] = useState(getCart());
 

  useEffect(() => {
    // Function to fetch all products
    const fetchProducts = async () => {
      try {
        const res = await fetch("http://localhost:4000/allproducts");
        if (!res.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await res.json();
        console.log("Fetched products:", data); // Debug: Check the data format
        setall_products(data); // Update state with fetched data
      } catch (error) {
        console.error("Error fetching products:", error); // Debug: Log any errors
      }
    };
  
    // Function to fetch cart items
    const fetchCartItems = async () => {
      try {
        const token = localStorage.getItem("auth-token");
        if (token) {
          const res = await fetch("http://localhost:4000/getcart", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "auth-token": token,
              "Content-Type": "application/json",
            },
            body: null, // No body required for this request
          });
  
          if (!res.ok) {
            throw new Error("Network response was not ok");
          }
          const data = await res.json();
          setcartItem(data);
        }
      } catch (error) {
        console.error("Error fetching cart items:", error); // Debug: Log any errors
      }
    };
  
    // Fetch products and cart items
    fetchProducts();
    fetchCartItems();
  }, []);  

  
  const addtocart = (id) => {
    setcartItem((prev) => ({
      ...prev,
      [id]: (prev[id] || 0) + 1,
    }));
    console.log(cartItem);
    if (localStorage.getItem("auth-token")) {
      fetch("http://localhost:4000/addtocart", {
        method: "POST",
        headers: {
          Accept: "application/form-data",
          "auth-token": `${localStorage.getItem("auth-token")}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: id }),
      })
        .then((response) => {
          response.json();
        })
        .then((data) => {
          console.log(data);
        });
    }
  };
  const removetocart = (id) => {
    setcartItem((prev) => ({ ...prev, [id]: prev[id] - 1 }));
    if (localStorage.getItem("auth-token")) {
      fetch("http://localhost:4000/deletetocart", {
        method: "POST",
        headers: {
          Accept: "application/form-data",
          "auth-token": `${localStorage.getItem("auth-token")}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: id }),
      })
        .then((response) => {
          response.json();
        })
        .then((data) => {
          console.log(data);
        });
    }
  };

  const GetAmount = () => {
    let total = 0;
    for (const item in cartItem) {
      if (cartItem[item] > 0) {
        let iteminfo = all_products.find(
          (product) => product.id === Number(item)
        );
        console.log(`now :${iteminfo}`);
        total += iteminfo.new_price * cartItem[item];
      }
    }
    return total;
  };
  const GetItem = () => {
    let totalitem = 0;
    for (const item in cartItem) {
      if (cartItem[item] > 0) {
        totalitem += cartItem[item];
      }
    }
    return totalitem;
  };
  const ContextValue = {
    all_products,
    GetAmount,
    GetItem,
    cartItem,
    addtocart,
    removetocart,
  };

  return (
    <ShopContext.Provider value={ContextValue}>
      {props.children}
    </ShopContext.Provider>
  );
};

export default ShopContextProvider;
