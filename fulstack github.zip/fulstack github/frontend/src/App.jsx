import { useState } from "react";
import logo from "./assets/logo.png";
import Navbar from "./components/Navbar";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Shop from "./Pages/Shop";
import ShopCatogory from "./Pages/ShopCatogory";
import Cart from "./Pages/Cart";
import Login from "./Pages/Login";
import Product from "./Pages/Product";
import Footer from "./components/Footer";
import bannermen from "./assets/banner_mens.png";
import bannerwomen from "./assets/banner_women.png";
import bannerkids from "./assets/banner_kids.png";
import ShopContextProvider from "./Context/ShopContext"; // Adjust the import path as needed


function App() {
  return (
    <>
       
      <ShopContextProvider>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route path="/" element={<Shop />}></Route>
          <Route path="/men" element={<ShopCatogory banner={bannermen} category="Men" />} />
          <Route path="/women" element={<ShopCatogory banner={bannerwomen} category="Women" />} />
          <Route path="/kid" element={<ShopCatogory banner={bannerkids} category="Kid" />} />
          <Route path="/cart" element={<Cart />}></Route>
          <Route path="/login" element={<Login />}></Route>
          <Route path="/product" element={<Product />}>
            <Route path=":productID" element={<Product />} />
          </Route>
        </Routes>
        <Footer />
      </BrowserRouter>
    </ShopContextProvider>
    </>
  );
}

export default App;
