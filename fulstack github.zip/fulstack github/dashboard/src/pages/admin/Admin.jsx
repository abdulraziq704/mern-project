import React from "react";
import { Routes, Route } from "react-router-dom";
import Sidebar from "../../components/Sidebar";
import AddProduct from "../../components/AddProduct";
import List from "../../components/List";

const Admin = () => {
  return (
    <>
      <div className="flex">
        <Sidebar />
        <Routes>
          <Route path="/addproduct" element={<AddProduct />} />
          <Route path="/list" element={<List />} />
        </Routes>
      </div>
    </>
  );
};

export default Admin;
