import React, { useState } from "react";
import load from "../assets/load.jpg";

const AddProduct = () => {
  const [img, setimg] = useState(null);
  const [details, setdetails] = useState({
    name: "",
    image: "",
    new_price: "",
    old_price: "",
    category: "Women",
  });

  const handler = (e) => {
    setimg(e.target.files[0]);
  };

  const detialhandler = (e) => {
    setdetails({ ...details, [e.target.name]: e.target.value });
  };

  const add_product = async () => {
    console.log(details);
    let response;
    let product = details;
    let formdata = new FormData();
    formdata.append("product", img) 

    await fetch( 'http://localhost:4000/upload',{
        method:"POST",
        headers:{
            Accept:"application/json"
        },
        body:formdata,

    }).then((resp)=>resp.json()).then((data)=>{response=data})
    
if(response.success){
    product.image= response.image_url;
    console.log(product);
    
    await fetch( 'http://localhost:4000/addproduct',{
        method:"POST",
        headers:{
            Accept:"Application/json",
            "Content-Type": "Application/json",
        },
        body:JSON.stringify(product),

    }).then((resp)=>resp.json()).then((data)=>{data.success?alert("Product Added Successfully"):alert("Failed ")})
}
  };

  return (
    <div className="w-1/2 bg-white p-5 m-4 border">
      <div className="flex flex-col gap-4 mb-3">
        <label htmlFor="name" className="px-3">
          Product Title
        </label>
        <input
          value={details.name}
          onChange={detialhandler}
          type="text"
          name="name"
          placeholder="Product Title"
          className="border py-2 px-4"
        />
      </div>
      <div className="md:flex gap-3">
        <div className="flex flex-col gap-4 mb-3 w-full">
          <label htmlFor="new_price" className="px-3">
            Price
          </label>
          <input
            value={details.new_price}
            onChange={detialhandler}
            type="number"
            name="new_price"
            placeholder="Price"
            className="border py-2 px-4"
          />
        </div>
        <div className="flex flex-col gap-4 mb-3 w-full">
          <label htmlFor="old_price" className="px-3">
            Offer Price
          </label>
          <input
            value={details.old_price}
            onChange={detialhandler}
            type="number"
            name="old_price"
            placeholder="Offer Price"
            className="border py-2 px-4"
          />
        </div>
      </div>
      <div className="flex flex-col gap-4 mb-3">
        <label htmlFor="category" className="px-3">
          Product Category
        </label>
        <select
          value={details.category}
          onChange={detialhandler}
          className="px-3"
          name="category"
          id="category"
        >
          <option value="Men">Men</option>
          <option value="Women">Women</option>
          <option value="Kid">Kid</option>
        </select>
      </div>
      <div>
        <label htmlFor="file-input">
          <img
            className="w-32 inline-flex"
            src={img ? URL.createObjectURL(img) : load}
            alt=""
          />
        </label>
        <input
          onChange={handler}
          type="file"
          hidden
          name="image"
          id="file-input"
        />
      </div>
      <div>
        <button
          className="bg-blue-500 rounded-md px-4 py-2 text-white"
          onClick={add_product}
        >
          Add Product
        </button>
      </div>
    </div>
  );
};

export default AddProduct;
