import React from "react";
import logo from "../assets/logo.png";
import img from '../assets/product_19.png'
import ico from '../assets/bread.png'


const Navbar = () => {
  return (
    <>
      <div className="flex justify-between items-center border font-poppins   bg-white py-3 px-6 md:px-24">
        <div className="flex gap-2">
          <img className="w-10" src={logo} alt="" />
          <div className="font-bold flex flex-col  ">
            <h2 className=" ">SHOPPER</h2>
            <h4 className="text-red-500 font-medium text-sm leading-[15px] ">Admin Panel</h4>
          </div>
        </div>

        <div className="flex justify-center items-center gap-2">
            
        <img  className="w-10 h-10 rounded-full object-cover " src={img} alt="" />
        <img className="w-2  rotate-90" src={ico} alt="" />
        </div>
      </div>
    </>
  );
};

export default Navbar;
