import React from "react";
import { Link } from "react-router-dom";

const Sidebar = () => {
  return (
    <>
      <div className="bg-gray-100 w-1/5 ">
        <div className="  border-r p-6 flex flex-col gap-4    h-[90vh] text-center">
          <Link
            to="/addproduct"
            className="hover:bg-gray-100 border bg-gray-50 rounded-md px-5 py-3"
          >
            Add Product
          </Link>
          <Link
            to="list"
            className="bg-gray-50 hover:bg-gray-100 border rounded-md px-5 py-3"
          >
            Product List
          </Link>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
