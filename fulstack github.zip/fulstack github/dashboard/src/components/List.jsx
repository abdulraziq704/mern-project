 import React, { useEffect, useState } from "react";
import cross from '../assets/cart_cross_icon.png';

const List = () => {
  const [allproducts, setallproducts] = useState([]);
  const [error, setError] = useState(null);

  const fetching = async () => {
    try {
      const res = await fetch("http://localhost:4000/allproducts");

      // Check if the response is OK (status in the range 200-299)
      if (!res.ok) {
        throw new Error(`HTTP error! Status: ${res.status}`);
      }

      // Attempt to parse the response as JSON
      const data = await res.json();
      setallproducts(data);
    } catch (error) {
      console.error('Fetch error:', error);
      setError(error.message);
    }
  };

  useEffect(() => {
    fetching();
  }, []);

  const removeitem = async( id) => { 
    await fetch('http://localhost:4000/removeproduct' , {
      method: 'POST',
      headers:{
        Accept:"Application/json",
        'Content-Type':'Application/json'
    },
    body:JSON.stringify({id:id}),
    })

    await fetching();

   }
  return (
    <>
      <div className="m-4 border w-full p-4">
        <h1 className="text-3xl font-bold mb-4">All Product List</h1>
        {error && <p className="text-red-500">Error: {error}</p>}
        <div className="py-4 grid md:grid-cols-6">
          <p>Product</p>
          <p>Title</p>
          <p>Category</p>
          <p>Old Price</p>
          <p>New Price</p>
          <p>Remove</p>
        </div>
        <div>
          <hr />
          {allproducts.map((product, index) => (
            <div key={index} className="grid md:grid-cols-6 items-center py-2 border-b">
              <img src={product.image} alt={product.title} className="w-16 h-16 object-cover" />
              <p>{product.name}</p>
              <p>{product.category}</p>
              <p>{product.old_price}</p>
              <p>{product.new_price}</p>
              <p>
                <img onClick={()=>{removeitem(product.id)}} src={cross} alt="Remove" className="w-4 h-4 cursor-pointer" />
              </p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default List;
