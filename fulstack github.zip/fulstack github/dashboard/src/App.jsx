  import React from "react"
import Navbar from "./components/Navbar"
 import List from "./components/List"
import Admin from "./pages/admin/Admin"
function App() {
 
  return (
    <> 
 <Navbar/>
 <Admin/> 

     </>
  )
}

export default App
